package HtmlApi;

public class Checkbox extends HtmlElement {
    private String type;
    private String value;
    private String label;

    public Checkbox(String name, String cssClass, String id, String value, String label) {
        super(name, cssClass, id);
        this.type = "radio";
        this.value = value;
        this.label = label;
    }

    public String makeCheckbox(Checkbox checkbox){
        StringBuilder sb = new StringBuilder();
        sb.append("<input type=\"");
        sb.append(type);
        sb.append("\" ");
        if( getName() != null){
            sb.append(checkbox.appendName(getName()));
        }
        if(getCssClass() != null){
            sb.append(checkbox.appendCssClass(getCssClass()));
        }
        if( getId() != null){
            sb.append(checkbox.appendId(getId()));
        }
        if(value != null){
            sb.append("value=\"");
            sb.append(value);
            sb.append("\"");
        }
        sb.append('>');
        if(label != null && getId() != null);
        sb.append("\n<label for=\"");
        sb.append(getId());
        sb.append("\">");
        sb.append(label);
        sb.append("</label>");
        return sb.toString();
    }
}