package HtmlApi;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

public class CheckboxTest {

    @Test
    public void testMakeCheckbox() {
        Checkbox ch = new Checkbox("myRadioButton","myCssClass","checkboxID",null, "Checkbox");
        assertThat(ch.makeCheckbox(ch), equalTo("<input type=\"radio\"  name=\"myCheckbox\" class=\"myCssClass\" id=\"checkboxID\">\n<label for=\"heckboxID\">Checkbox</label>"));
    }
}