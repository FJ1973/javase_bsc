package HtmlApi;

import junit.framework.TestCase;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

public class HeadTest  {

    @Test
    public void testMakeHead() {
        Head head = new Head("myTitle", "UTF-8", "myScript", "myStyle");
        assertThat(Head.makeHead(head), equalTo("<head>\n<title>myTitle</title>\n<meta charset=\"UTF-8\">\n<script src=\"myScript\">\n<style id=\"myStyle\">\n</head>\n"));
    }
}