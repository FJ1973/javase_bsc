package HtmlApi;

import org.junit.Test;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

public class BodyTest {

    @Test
    public void testMakeBody() {
        Body body = new Body();
        assertThat(body.makeBody(), equalTo("<body>\n</body>\n"));
    }

    @Test
    public void testInsertAnotherElement() {
        Body b = new Body();
        String body = b.makeBody();
        String otherElement = "<div>\n</div>";
        assertThat(b.insertAnotherElement(body, otherElement), equalTo("<body>\n<div>\n</div>\n</body>\n"));
    }
}