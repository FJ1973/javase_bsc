package HtmlApi;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

public class DivTest{

    @Test
    public void testMakeDiv() {
        Div d = new Div("myDiv", "myCssClass", "myID");
        assertThat(d.makeDiv(d), equalTo("<div name=\"myDiv\" class=\"myCssClass\" id=\"myID\">\n</div>"));
    }

    @Test
    public void testInsertAnotherElement() {
        Div d = new Div(null, null, null);
        Checkbox ch = new Checkbox("myCheckbox",null,"checkboxID",null, "Checkbox");
        assertThat(d.insertAnotherElement(d.makeDiv(d), ch.makeCheckbox(ch)),
                equalTo("<div>\n<input type=\"checkbox\"  name=\"myCheckbox\" id=\"checkboxID\">\n<label for=\"checkboxID\">Checkbox</label>\n</div>"));
    }
}