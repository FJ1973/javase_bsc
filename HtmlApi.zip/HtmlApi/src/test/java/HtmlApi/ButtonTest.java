package HtmlApi;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

public class ButtonTest{
    @Test
    public void testMakeButton() {
    Button button = new Button("buttonText", "buttonName", "buttonCssClass",
            "buttonid", "buttonOnClickevent", true, false, "buttonForm", "button");
    assertThat(button.makeButton(button), equalTo("<button onclick=\"buttonOnClickevent\" autofocus form=\"buttonForm\" name=\"buttonName\" class=\"buttonCssClass\" id=\"buttonid\" type=\"button\">buttonText</button>"));

    }
}