package HtmlApi;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

public class TableTest{

    @Test
    public void testMakeTable() {
        Table table = new Table("name", "cssclass", "id", 4, 2, null, "caption");
        assertThat(table.makeTable(table), equalTo("<table  id=\"id\" name=\"name\" class=\"cssclass\">\n" +
                "<caption>caption</caption>\n" +
                "<tr>\n" +
                "<th></th>\n" +
                "<th></th>\n" +
                "<th></th>\n" +
                "<th></th>\n" +
                "</tr>\n" +
                "<tr>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "</tr>\n" +
                "</table>\n"));
    }

    @Test
    public void testInsertRows() {
        Table table = new Table("name", "cssclass", "id", 4, 2, null, "caption");
        assertThat(table.insertRows(table.makeTable(table), 4,3), equalTo("<table  id=\"id\" name=\"name\" class=\"cssclass\">\n" +
                "<caption>caption</caption>\n" +
                "<tr>\n" +
                "<th></th>\n" +
                "<th></th>\n" +
                "<th></th>\n" +
                "<th></th>\n" +
                "</tr>\n" +
                "<tr>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "</tr>\n" +
                "<tr>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "</tr>\n" +
                "<tr>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "</tr>\n" +
                "<tr>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "<td></td>\n" +
                "</tr>\n" +
                "</table>\n"));
    }
}