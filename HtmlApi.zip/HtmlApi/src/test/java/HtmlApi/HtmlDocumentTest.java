package HtmlApi;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

public class HtmlDocumentTest {

    @Test
    public void testGenerateHtmlDocument(){
        HtmlDocument document = new HtmlDocument();
        Head head = new Head(null, "UTF-8", null, null);
        Body body = new Body();
        assertThat(document.generateHtmlDocument(Head.makeHead(head), body.makeBody()),
        equalTo("<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\"UTF-8\">\n</head>\n<body>\n</body>\n</html>"));
    }
}